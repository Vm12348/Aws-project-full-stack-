<!-- Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved. -->
<!-- SPDX-License-Identifier: MIT-0 -->

<template>
  <div class="about">
    <h3>Just a demo ;)</h3>
    
  </div>
</template>

<style scoped>

h3 {
  text-shadow: gray;
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  color: white;
  text-align: center;
  padding: 10px;
}

.about {
  padding: 60px;
}

</style>
