# Backend of the demo app

## Project setup
```
npm install
```
### Compiles and hot-reloads for development
```
npm start
```